import userListSlice from './slice';

export default userListSlice.reducer;
