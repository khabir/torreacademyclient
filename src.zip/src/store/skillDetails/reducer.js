import skillDetailsSlice from "./slice";

export default skillDetailsSlice.reducer;
