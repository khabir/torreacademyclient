export const selectSkillDetails = (state) => state.ui.skillDetails.data;
