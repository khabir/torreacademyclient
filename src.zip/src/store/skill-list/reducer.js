import skillListSlice from './slice';

export default skillListSlice.reducer;
