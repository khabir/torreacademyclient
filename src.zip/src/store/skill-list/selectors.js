export const selectSkillList = (state) => state.ui.skillList.data;
