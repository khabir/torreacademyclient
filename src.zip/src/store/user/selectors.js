export const selectUserSkills = (state) => state.ui.user.data;
