import userSlice from "./slice";

export default userSlice.reducer;
