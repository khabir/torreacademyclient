function getTheFirstWord(str) {
  var arr = str.split(' ', 2);
  return arr[0];
}
export default getTheFirstWord;
